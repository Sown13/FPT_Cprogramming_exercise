#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "password_checker.h"

// Declare conditions.
char upperCases[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
    'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
    'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

char lowerCases[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
    'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
    's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

char specials[] = {'`', '!', '\"', '?', '$', '?', '%', '^', '&',
    '*', '(', ')', '_', '-', '+', '=', '{', '[',
    '}', ']', ':', ';', '@', '\'', '~', '#', '|',
    '\\', '<', '>', '.', '?'};

char numbers[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

int main() {
	// Student code here.
}

char *input_password_interface() {
	// Student code here.
}

// Check password health.
// Return -1: password length is smaller than 10 characters.
// Return 0: password contains invalid characters.
// Return 1 or return 2: password health is low.
// Return 3: password health is medium.
// Return 4: password health is strong.

int check_password_health(char *password) {
   	// Student code here.
}

// Create interface to print result to monitor.

void print_result_interface(int health) {
    // Student code here.
}




